const Juri = require('../models/juriModel');

exports.create = async (req, res) => {
  try {
    const juri = await Juri.create(req.body);
    res.status(201).json(juri);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

exports.getAll = async (req, res) => {
  res.json(await Juri.find());
};