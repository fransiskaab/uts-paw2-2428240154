const mongoose = require('mongoose');

const penulisSchema = new mongoose.Schema({
  nama: String,
  sekolah: String,
}, { _id: false });

const naskahSchema = new mongoose.Schema({
  kodeNaskah: { type: String, required: [true, 'kodeNaskah wajib diisi'], unique: true, trim: true },
  judul: { type: String, required: [true, 'judul wajib diisi'], trim: true },
  jumlahKata: { type: String, required: [true, 'jumlahKata wajib diisi'], trim: true },
  kategori: { type: String, required: [true, 'kategori wajib diisi'], trim: true },
  penulis: penulisSchema,
  juriId: { type: mongoose.Schema.Types.ObjectId, ref: 'juri' },
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model('naskah', naskahSchema);