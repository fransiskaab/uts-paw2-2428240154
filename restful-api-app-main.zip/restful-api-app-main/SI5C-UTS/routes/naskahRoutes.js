const express = require('express');
const router = express.Router();
const naskahController = require('../controllers/naskahController');
const cekApiKey = require('../middlewares/cekApiKey');

router.get('/', naskahController.getAll);
router.get('/:id', naskahController.getById);
router.post('/', cekApiKey, naskahController.create);
router.put('/:id', cekApiKey, naskahController.update);
router.delete('/:id', cekApiKey, naskahController.remove);

module.exports = router;